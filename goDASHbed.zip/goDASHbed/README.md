# goDashbed Application

To install the Cooperative version of goDASHbed first install the orginal goDASHbed in the same folder as the cooperative version of goDASH using this link https://www.dropbox.com/sh/kjekwrtcu8yhhxq/AAB3i_IQHBBg1fqj64IKfonia?dl=0

Once installed replace the goDASHbed.py file in the created goDASHbed folder with the goDASHbed.py file that came in the zip with this README

current version : 0.6.1
-> git checkout godashbed_v0.6.1

GoDASHbed is a mininet test environment for goDASH


Steps for installation:

download dash content to <content_folder>, using "get_your_movies.sh"
sudo mv <content_folder> /var/www/html

sudo adduser $USER www-data
sudo chown $USER:www-data -R /var/www
sudo chmod u=rwX,g=srX,o=rX -R /var/www

update the url lists in "urls/mpdURL.py" to reflect the content downloaded
/var/www/html/<folder> -> "http://www.goDASHbed.org/<folder>"

You may also need to update the "configure.json" file in goDASHbed/config, and change 'url' to point to the content downloaded - "url" : "[http://www.goDASHbed.org/<folder>]"

if using tcp with https - change http to https in the configure.json file and in the "urls/mpdURL.py" file
if using quic - change http to https in the configure.json file and in the "urls/mpdURL.py" file

to use tcp http(s) in goDASHbed, you need to modify the following file:
goDASHbed/caddy-config/TesbedTCP/Caddyfile

on line 10, change the following:
tls <godash folder location>/goDash/DashApp/src/goDASH/http/certs/cert.pem <godash folder location>/goDash/DashApp/src/goDASH/http/certs/key.pem

add the folder location that you downloaded goDASH to
Easiest way to find this location, is to open the folder that you added goDASH to, then open terminal, type "pwd" and return, the reply is the folder location.  Add this output text into the "Caddyfile" replacing "<godash folder location>" in the two locations needed.

example call to goDashBed.py:
>sudo python3 ./goDashBed.py -b 10 --videoclients 3 --duration 40 --voipclients 1 --debug="off" --numruns 1 --tm "tcp"

-b - bandwidth of bottleneck link
--videoclients - number of goDASH clients
--duration - duration of experiment in seconds - will be ultiliately determined based on trace lenght, and clip lenght
--voipclients - number of voip clients - based on D-ITG traffic generator
--debug - defines if the debug logs should be created - note: even if "debug" is set to "off", a log file, "logDownload.txt", containing the output features of each downloaded segment will be created per client.
--numruns 1 - repeat the experiment X number of times
--tm "tcp" - utilise TCP for network transport protocol - changing MPD url from http to https facilitate secure transmission.  An additional option for --tm is "quic" - which mandates the https protocol in the MPD url.

The goDASHbed folder contains a number of sub-folders:
"caddy-config" - contains the configuration file for the caddy web server
"config" - contains the original configure.json file for these goDASH clients.  The "terminalPrint" and "debug" setting passed into the script will overwrite the respective "terminalPrint" and "debug" settings in this config file.
"traces" - contains the 3G/4G/5G traces upon which the throughput of the bottleneck is determined
"urls" - contains a list of the possible urls to choose from.  This will depend on the clips that have been downloaded and placed in the /var/web/html/ fodler of the VM

Once "goDashBed.py" is run, a number of additional files/folders are created:

"output" - For each run, the "output" folder will contain a new folder defined by a run number, i.e., "R1", and with in this run folder, a new folder defined by a time stamp

Within this folder, e.g.: "2020-01-09-06-42-20", 3 folders will be created:
"config" - contains a newly generated config file for each client (numbered per client).  The url for each client, will be randomly chosen from the list of MPDs contained within the "urls" folder.  
"files" - contains a folder per client, within which, is each downloaded segment and the requested MPD file.  Each client folder will also contain a "logDownload.txt" file, which contains the per segment download information.
"logs" - will contain the debug logs if "debug" is set to on.  This folder will also contain the header information for all segments across all of the MPD urls, if "getHeaders" is set to on.
Note: if getHeaders is set to "on", the headers will be downloaded to the log folder, then the script will auto-run, to re-call the clients with the requested algorithm.

"test-R<run number>" - contains a file containing a summary of the VOIP traffic.

"access.log" - contains relavent output information on the requests from the goDASH clients to the web server

"voipclients" - contains relavent output information on the settings for the VOIP client(s)
